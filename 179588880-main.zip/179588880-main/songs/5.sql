Select AVG(energy) from songs;
