Select title from movies where year >= 2018  Order By title ASC;
