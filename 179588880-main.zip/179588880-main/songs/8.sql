Select name from songs where name LIKE '%feat.%';
