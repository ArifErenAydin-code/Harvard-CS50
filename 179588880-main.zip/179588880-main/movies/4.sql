Select COUNT(movie_id) from ratings where rating = 10.0;
