Select name from songs WHERE artist_id =( Select id from artists where  name = 'Post Malone');
