Select name from songs ORDER BY tempo;
