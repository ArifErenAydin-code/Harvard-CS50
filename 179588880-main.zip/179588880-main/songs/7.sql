Select AVG(energy) from songs where artist_id = (Select id from artists where name = 'Drake');
